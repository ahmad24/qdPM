---
---
-- from version 4.x to 4.2
ALTER TABLE `extra_fields` ADD `display_in_list` TINYINT( 1 ) NULL
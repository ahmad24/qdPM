<div id="footerContainer">
  <div id="footerBox">
    <a href="http://qdpm.net" target="_blank">qdPM 8.1</a> <br> Copyright &copy; <?php echo  date('Y') ?> <a href="http://qdpm.net" target="_blank">qdpm.net</a>
  </div>
</div>

<h1><?php echo __('New Comment') ?></h1>

<?php include_partial('form', array('form' => $form,'tasks'=>$tasks,'projects'=>$projects)) ?>

<h1><?php echo __('Edit Comment') ?></h1>

<?php include_partial('form', array('form' => $form,'discussions'=>$discussions,'projects'=>$projects)) ?>

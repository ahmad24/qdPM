<h1><?php echo __('Edit Group') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>

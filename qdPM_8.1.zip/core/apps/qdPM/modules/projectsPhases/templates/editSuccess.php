<h1><?php echo __('Edit Phase') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>

<h1><?php echo __('New Version') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>

<h1><?php echo __('Access Forbidden') ?></h1>
<?php echo __('Sorry, you don\'t have access to this page.')?>
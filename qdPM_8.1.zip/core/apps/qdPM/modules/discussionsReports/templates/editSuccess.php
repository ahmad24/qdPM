<h1><?php echo __('Edit Report') ?></h1>

<?php include_partial('form', array('form' => $form)) ?>

<?php

/**
 * TasksComments form.
 *
 * @package    sf_sandbox
 * @subpackage form
 * @author     Your name here
 * @version    SVN: $Id: sfDoctrineFormTemplate.php 23810 2009-11-12 11:07:44Z Kris.Wallsmith $
 */
class TasksCommentsForm extends BaseTasksCommentsForm
{
  public function configure()
  {
    $tasks = $this->getOption('tasks');
    
    if($this->getObject()->isNew())
    {
      $this->widgetSchema['tasks_priority_id'] = new sfWidgetFormChoice(array('choices'=>app::getItemsChoicesByTable('TasksPriority',true)));        
      $this->widgetSchema['tasks_status_id'] = new sfWidgetFormChoice(array('choices'=>app::getItemsChoicesByTable('TasksStatus',true)));                    
      $this->widgetSchema['due_date'] = new sfWidgetFormInput(array(),array('class'=>'datetimepicker'));
    }
    else
    {
      $this->widgetSchema['tasks_priority_id'] = new sfWidgetFormInputHidden();
      $this->widgetSchema['tasks_status_id'] = new sfWidgetFormInputHidden();
      $this->widgetSchema['due_date'] = new sfWidgetFormInputHidden();
    }
    
            
    $this->widgetSchema['created_by'] = new sfWidgetFormInputHidden();
    
    $this->setDefault('created_at', date('Y-m-d H:i:s'));        
    
    $this->widgetSchema['description']->setAttributes(array('class'=>'editor'));
    $this->widgetSchema['worked_hours']->setAttributes(array('size'=>'4'));    
    
    $this->widgetSchema['tasks_id'] = new sfWidgetFormInputHidden();    
    $this->setDefault('tasks_id', $tasks->getId());
    
    $this->widgetSchema->setLabels(array('tasks_priority_id'=>'Priority',
                                         'tasks_types_id'=>'Type',
                                         'tasks_labels_id'=>'Label',                                         
                                         'tasks_status_id'=>'Status',
                                         'worked_hours'=>'Work Hours',                                         
                                         'due_date'=>'Due Date',
                                         'created_at'=>'Created At',
                                         ));
    

  }
}
